
### LTTNG Instrumentation

A lttng-instrumented NGINX version is available. Enable lttng-tracing as follows:   

```bash
git clone https://gitlab.devtools.intel.com/cdn/nginx-dev
cd nginx-dev/nginx-1.16.1
./configure --with-lttng
```

### Customize LTTNG Tracing Code

Edit `src/trace/ngx_trace.h` to add lttng tracing function definition, an example as follows:  

```
TRACEPOINT_EVENT_INSTANCE(
    nginx,
    null_argv,
    ngx_crypt,
    TP_ARGS()
)
```

Then in any NGINX code, add the tracing statement as follows:   

```
#include "ngx_trace.h"

...

tracepoint(nginx, ngx_crypt)
```

Then run `./configure --with-lttng` and `make`.   

### Pre-defined LTTNG Event Classes

The following event classes are defined to include parameters into the LTTNG tracing points: 

```
TRACEPOINT_EVENT_CLASS(
    nginx,
    name_argv,
    TP_ARGS( u_char*, name ),
    TP_FIELDS( ctf_string( name, name ) )
)

TRACEPOINT_EVENT_CLASS(
    nginx,
    size_argv,
    TP_ARGS( size_t, size ),
    TP_FIELDS( ctf_integer(size_t, size, size) )
)

TRACEPOINT_EVENT_CLASS(
    nginx,
    opcode_argv,
    TP_ARGS( int, opcode ),
    TP_FIELDS( ctf_integer(int, opcode, opcode) )
)

TRACEPOINT_EVENT_CLASS(
    nginx,
    null_argv,
    TP_ARGS(),
    TP_FIELDS()
)
```

### Known Limitation

The instrumentation trace points only show up in `lttng list --userspace` if the nginx is configured with `daemon off`.   

