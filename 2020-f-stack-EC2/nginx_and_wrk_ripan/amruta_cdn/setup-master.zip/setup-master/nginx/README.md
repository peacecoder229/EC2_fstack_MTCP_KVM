
### Build

```bash
sudo dnf install -y libxml2-devel libxslt-devel
sudo mkdir -p /home/cdn/var/www/tmp

NGINX_VER=1.16.1
NGINX_REPO=https://nginx.org/download/nginx-${NGINX_VER}.tar.gz
wget -O - ${NGINX_REPO} | tar xz
cd nginx-${NGINX_VER}
./configure --prefix=/home/cdn/var/www --sbin-path=/home/cdn/sbin/nginx --modules-path=/home/cdn/lib64/nginx/modules --conf-path=/home/cdn/etc/nginx/nginx.conf --error-log-path=/home/cdn/var/www/log/error.log --pid-path=/home/cdn/var/www/nginx.pid --lock-path=/home/cdn/var/www/nginx.lock --http-log-path=/home/cdn/var/www/log/access.log --http-client-body-temp-path=/home/cdn/var/www/tmp/client_body --http-proxy-temp-path=/home/cdn/var/www/tmp/proxy --http-fastcgi-temp-path=/home/cdn/var/www/tmp/fastcgi --http-uwsgi-temp-path=/home/cdn/var/www/tmp/uwsgi --http-scgi-temp-path=/home/cdn/var/www/tmp/scgi --user=nobody --group=nobody --with-select_module --with-poll_module --with-threads --with-file-aio --with-http_ssl_module --with-http_v2_module --with-http_realip_module --with-http_addition_module --with-http_xslt_module --with-http_sub_module --with-http_dav_module --with-http_flv_module --with-http_mp4_module --with-http_gunzip_module --with-http_gzip_static_module --with-http_auth_request_module --with-http_random_index_module --with-http_secure_link_module --with-http_degradation_module --with-http_slice_module --with-http_stub_status_module --with-stream --with-stream_ssl_module --with-stream_realip_module --with-stream_ssl_preread_module --with-pcre
make
sudo make install
```

### Prepare Cache Disks (example assumes 2 NVMe disks)

Partition:

```bash
sudo fdisk /dev/nvme0n1   # create a primary partition
sudo fdisk /dev/nvme1n1   # create a primary partition 
sudo chown nobody /dev/nvme?n1p1
```

Format as ext4 (or xfs):
```bash
mkfs.ext4 -F /dev/nvme0n1p1
mkfs.ext4 -F /dev/nvme1n1p1
```

Create cache mountpoints and specify in the nginx configuration (as in the next step):
```bash
mkdir /mnt/cache0 /mnt/cache1
mount -o defaults,noatime,nodiratime /dev/nvme0n1p1 /mnt/cache0
mount -o defaults,noatime,nodiratime /dev/nvme1n1p1 /mnt/cache1
```

### Configure NGINX 

- Edit `/home/cdn/etc/nginx/nginx.conf` as follows:  

```bash
nginx as https proxy use nginx.conf
nginx as http proxy use nginx_http.conf
```

- Run the script [gencert.sh](../cert/gencert.sh) to generate a root CA, an intemediate CA, and a server certificate. 

- Make the CA chain trusted on the local or remote system:  

```bash
sudo cp -f ca/intermediate/certs/cdn-chain.cert.pem /etc/pki/ca-trust/source/anchors
sudo update-ca-trust extract
```

- Start NGINX:   

```bash
sudo /home/cdn/sbin/nginx
```


### Setup Content Origin

See [Origin Setup](../origin/README.md)

### Setup Debug Version

- Please add --with-debug in the ./configure phase
- Please add debug level as "error_log /path/to/log debug"

After that you could find the debug log in your defined log file location, for example, /var/www/error.log.

### Setup LTTNG Tracing

See [instrument.md](instrument.md) for details. 


