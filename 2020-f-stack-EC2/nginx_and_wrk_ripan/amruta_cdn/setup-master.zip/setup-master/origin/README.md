# Set up Content Origin

## Set up `http_obj_gen` object generator  

```bash
sudo dnf install python
sudo pip install numpy

git clone https://gitlab.devtools.intel.com/cdn/cdn-tools
cd cdn-tools/origin
nohup python2 http_obj_gen.py --host localhost --port 8888 --obj-dist fixed > /dev/null 2> /dev/null &
```

## Set up the NGINX frontend for the content origin:   

```bash
# Build NGINX
sudo dnf install -y libxml2-devel libxslt-devel
sudo mkdir -p /usr/local/var/www/tmp

NGINX_VER=1.16.1
NGINX_REPO=https://nginx.org/download/nginx-${NGINX_VER}.tar.gz
wget -O - ${NGINX_REPO} | tar xz
cd nginx-${NGINX_VER}
./configure --prefix=/usr/local/var/www --sbin-path=/usr/local/sbin/nginx --modules-path=/usr/local/lib64/nginx/modules --conf-path=/usr/local/etc/nginx/nginx.conf --error-log-path=/usr/local/var/www/log/error.log --pid-path=/usr/local/var/www/nginx.pid --lock-path=/usr/local/var/www/nginx.lock --http-log-path=/usr/local/var/www/log/access.log --http-client-body-temp-path=/usr/local/var/www/tmp/client_body --http-proxy-temp-path=/usr/local/var/www/tmp/proxy --http-fastcgi-temp-path=/usr/local/var/www/tmp/fastcgi --http-uwsgi-temp-path=/usr/local/var/www/tmp/uwsgi --http-scgi-temp-path=/usr/local/var/www/tmp/scgi --user=nobody --group=nobody --with-select_module --with-poll_module --with-threads --with-file-aio --with-http_ssl_module --with-http_v2_module --with-http_realip_module --with-http_addition_module --with-http_xslt_module --with-http_sub_module --with-http_dav_module --with-http_flv_module --with-http_mp4_module --with-http_gunzip_module --with-http_gzip_static_module --with-http_auth_request_module --with-http_random_index_module --with-http_secure_link_module --with-http_degradation_module --with-http_slice_module --with-http_stub_status_module --with-stream --with-stream_ssl_module --with-stream_realip_module --with-stream_ssl_preread_module --with-pcre
make
sudo make install
```

### Create Content Cache mount point (tmpfs)
```
sudo mkdir -p /mnt/content-cache0
sudo mount -t tmpfs -o size=10g tmpfs /mnt/content-cache0
```

### Create nginx.conf
Copy [nginx-origin.conf](nginx-origin.conf) to `/usr/local/etc/nginx/nginx.conf`

### Start nginx
```
sudo /usr/local/sbin/nginx -s reload
```
