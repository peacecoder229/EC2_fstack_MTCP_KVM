
### Build wrk+llnw

```bash
sudo yum install -y openssl-devel

git clone https://gitlab.devtools.intel.com/cdn/wrk-llnw.git
cd wrk-llnw
make
```

### Quick Test

```bash
sudo ./run-wrk1.sh
```

### Benchmark

```bash
sudo ./run-wrk.sh
```

### Tuning #threads & #connections

Run the [tune-wrk.sh](tune-wrk.sh) script as follows:   

```bash
sudo ./tune-wrk.sh | tee wrk-logs.txt
```

