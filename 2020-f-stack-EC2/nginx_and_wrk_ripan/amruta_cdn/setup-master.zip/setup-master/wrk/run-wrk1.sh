#!/bin/bash -e

ulimit -n 65535
DIR=$(dirname $(readlink -f "$0"))
threads=${1:-104}
conns=${2:-400}
url=${3:-http://192.168.1.200:8080}
wrk=${4:-$DIR/../../wrk-llnw/wrk}

$wrk -t $threads -c $conns -d 30s $url/kk/kk
