
- Run the script [gencert.sh](gencert.sh) to generate a root CA, an intemediate CA, and a server certificate. 

- Make the CA chain trusted on the local or remote system:  

```bash
sudo cp -f ca/intermediate/certs/cdn-chain.cert.pem /etc/pki/ca-trust/source/anchors
sudo update-ca-trust extract
```

