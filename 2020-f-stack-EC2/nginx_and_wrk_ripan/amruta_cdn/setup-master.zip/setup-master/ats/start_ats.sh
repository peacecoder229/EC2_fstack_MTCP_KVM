#!/bin/bash
ats_dir=/usr/local/

echo "[Stopping ATS]"
sudo $ats_dir/bin/trafficserver stop
echo "[Clearing Host Cache]"
echo 3 | sudo tee /proc/sys/vm/drop_caches
echo "[Removing ATS Logs]"
sudo rm -v $ats_dir/var/log/trafficserver/*
echo "[Changing permissions to storage drives]"
sudo chown -v nobody:trafficserver /dev/nvme*

#echo "[Changing permisions to ramdisks]"
#sudo chown -v nobody:trafficserver /dev/ram*
#sudo chown -v nobody:trafficserver /tmp/ramdisk*

echo "[Starting ATS]"
sudo $ats_dir/bin/trafficserver start
echo "[Checking ATS Status]"
sudo $ats_dir/bin/trafficserver status

sleep 10

tail $ats_dir/var/log/trafficserver/diags.log

exit 0
