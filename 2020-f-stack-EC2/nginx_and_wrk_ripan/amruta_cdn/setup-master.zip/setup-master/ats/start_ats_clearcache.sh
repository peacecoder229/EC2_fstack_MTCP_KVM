#!/bin/bash
ats_dir=/usr/local/
script_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"


echo "[Stopping ATS]"
sudo $ats_dir/bin/trafficserver stop
echo "[Clearing ATS Cache]"
sudo $ats_dir/bin/traffic_server -Cclear


${script_dir}/start_ats.sh

exit 0
