-  Adding QAT Engine to ATS

```
...
sudo yum -y install perl

wget https://www.openssl.org/source/openssl-1.1.1f.tar.gz
tar -xf openssl-1.1.1f.tar.gz
cd openssl-1.1.1f
./config --prefix=/opt/openssl -Wl,-rpath,/opt/openssl/lib  -d -g3 -ggdb3
make depend
make
make install

sudo yum -y install yum install boost-devel libudev-devel pkgconfig
mkdir /QAT
cd /QAT
wget https://01.org/sites/default/files/downloads/qat1.7.l.4.9.0-00008.tar_0.gz
tar -xf qat1.7.l.4.9.0-00008.tar_0.gz
yum -y install libudev-devel
./configure
make
make install

------------- NOTE: after kernel change rebuild QAT driver, ------------------
------------- clear dir first and unpack tar again. --------------------------


wget https://github.com/intel/QAT_Engine/archive/v0.5.44.tar.gz
tar -xf v0.5.44.tar.gz
cd QAT_Engine
./autogen.sh
./configure --with-qat_dir=/QAT --with-openssl_install_dir=/opt/openssl -- enable-qat_warnings --enable-qat_debug --enable-qat_mem_warnings --with-qat_debug_file=/usr/local/var/log/trafficserver/qat.log
make
make install


----------- Choose and copy correct QAT Driver config files from: ---------------
----------- /path/to/qat_engine/qat/config/c6xx to /etc/ ------------------------
----------- make sure it includes [SHIM] section --------------------------------

reload engine:
service qat_service restart

run ./openssl speed -engine qat -elapsed -async_jobs 72 rsa2048 && ./openssl speed -elapsed -async_jobs 72 rsa2048

check the results - results without QAT engine offload should be significantly lower across the board.


-----------  Edit records.conf -------------------------------------------------------
---------- add lines before setting up certificates: ---------------------------------
---------- change the path of load_engine.cnf to the one that applies to
---------- load_engine location on your system ----------

CONFIG proxy.config.ssl.async.handshake.enabled INT 1
CONFIG proxy.config.ssl.engine.conf_file STRING /home/moleksy/ats-dev/ats-8.0.x/contrib/openssl/load_engine.cnf

------------------------------------------------------------------

------------   load_engine.cnf contains: -------------------------

openssl_conf = openssl_init

[openssl_init]

engines = engine_section

[engine_section]

async = async_section

[async_section]

dynamic_path = /opt/openssl/lib/engines-1.1/qat.so

engine_id = qat

default_algorithms = ALL

init = 1

------------------------------------------------------------------

setup hugepages:
vim /etc/sysctl.conf
add:
vm.nr_hugepages = 2048
reload params with:
sysctl -p
or better restart

...
```