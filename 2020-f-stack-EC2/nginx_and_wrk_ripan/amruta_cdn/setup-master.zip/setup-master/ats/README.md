### Build ATS

```bash
sudo dnf install -y autoconf automake libtool pkgconfig perl-ExtUtils-MakeMaker openssl-devel pcre-devel ncurses-devel libcurl-devel libcap-devel flex tcl-devel
sudo dnf --enablerepo=PowerTools install -y hwloc-devel

git clone https://github.com/apache/trafficserver
cd trafficserver
git checkout tags/8.0.6
autoreconf -if
./configure --with-tcmalloc-pagesize=64
make
sudo make install
```

### Configure ATS

- Edit `/usr/local/etc/trafficserver/records.config`:   

```
# info
CONFIG proxy.config.http.response_server_str STRING vCDN
CONFIG proxy.config.proxy_name STRING jf3clx001
CONFIG proxy.config.http_ui_enabled INT 3

# interface
CONFIG proxy.config.http.server_ports STRING 8080:proto=http;http2 8080:proto=http;http2:ipv6 8443:ssl 8443:ssl:ipv6

# timeout
CONFIG proxy.config.http.parent_proxy.connect_attempts_timeout INT 4
CONFIG proxy.config.http.keep_alive_no_activity_timeout_in INT 600
CONFIG proxy.config.http.keep_alive_no_activity_timeout_out INT 4
CONFIG proxy.config.http.transaction_active_timeout_in INT 3600
CONFIG proxy.config.net.default_inactivity_timeout INT 300

# caching
CONFIG proxy.config.http.negative_caching_enabled INT 1
CONFIG proxy.config.http.negative_caching_lifetime INT 120
CONFIG proxy.config.http.wait_for_cache INT 1
CONFIG proxy.config.http.cache.when_to_revalidate INT 3
CONFIG proxy.config.http.cache.required_headers INT 0
CONFIG proxy.config.http.cache.heuristic_min_lifetime INT 8640000
CONFIG proxy.config.http.cache.heuristic_max_lifetime INT 8640000
CONFIG proxy.config.http.cache.max_stale_age INT 0
CONFIG proxy.config.http.cache.max_open_read_retries INT 10
CONFIG proxy.config.http.cache.open_read_retry_time INT 20
CONFIG proxy.config.http.cache.ignore_client_no_cache INT 1
CONFIG proxy.config.http.cache.ims_on_client_no_cache INT 0
CONFIG proxy.config.http.cache.ignore_server_no_cache INT 1

CONFIG proxy.config.cache.ram_cache_cutoff INT 536870912
CONFIG proxy.config.cache.ram_cache.use_seen_filter INT 0
CONFIG proxy.config.cache.ram_cache.algorithm INT 1
CONFIG proxy.config.cache.min_average_object_size INT 1048576
CONFIG proxy.config.cache.threads_per_disk INT 16
CONFIG proxy.config.cache.enable_read_while_writer INT 1
CONFIG proxy.config.cache.read_while_writer.max_retries INT 20

# logging
CONFIG proxy.config.log.max_space_mb_for_logs INT 75000
CONFIG proxy.config.log.rolling_enabled INT 3
CONFIG proxy.config.log.rolling_interval_sec INT 300
CONFIG proxy.config.log.rolling_size_mb INT 30
CONFIG proxy.config.log.logfile_dir STRING /usr/local/var/log/trafficserver
CONFIG proxy.config.log.sampling_frequency INT 1
CONFIG proxy.config.log.max_space_mb_for_orphan_logs INT 2000
CONFIG proxy.config.output.logfile.rolling_enabled INT 2

# url remap
CONFIG proxy.config.url_remap.pristine_host_hdr INT 1

# ssl
CONFIG proxy.config.ssl.server.cipher_suite STRING ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-AES256-GCM-SHA384:DHE-RSA-AES128-GCM-SHA256:DHE-DSS-AES128-GCM-SHA256:kEDH+AESGCM:ECDHE-RSA-AES128-SHA256:ECDHE-ECDSA-AES128-SHA256:ECDHE-RSA-AES128-SHA:ECDHE-ECDSA-AES128-SHA:ECDHE-RSA-AES256-SHA384:ECDHE-ECDSA-AES256-SHA384:ECDHE-RSA-AES256-SHA:ECDHE-ECDSA-AES256-SHA:DHE-RSA-AES128-SHA256:DHE-RSA-AES128-SHA:DHE-DSS-AES128-SHA256:DHE-RSA-AES256-SHA256:DHE-DSS-AES256-SHA:DHE-RSA-AES256-SHA:!aNULL:!eNULL:!EXPORT:!DES:!RC4:!3DES:!MD5:!PSK
CONFIG proxy.config.ssl.TLSv1 INT 0
CONFIG proxy.config.ssl.TLSv1_1 INT 0
CONFIG proxy.config.ssl.TLSv1_2 INT 1
CONFIG proxy.config.ssl.TLSv1_3 INT 0
CONFIG proxy.config.ssl.server.cert.path STRING /usr/local/etc/sslcert
CONFIG proxy.config.ssl.server.private_key.path STRING /usr/local/etc/sslcert
CONFIG proxy.config.ssl.client.verify.server INT 0
CONFIG proxy.config.ssl.client.CA.cert.filename STRING NULL
CONFIG proxy.config.ssl.client.certification_level INT 1
CONFIG proxy.config.ssl.CA.cert.path STRING NULL

# debugging
CONFIG proxy.config.diags.debug.enabled INT 1
CONFIG proxy.config.diags.debug.tags STRING NULL
CONFIG proxy.config.body_factory.template_sets_dir STRING etc/trafficserver/body_factory
CONFIG proxy.config.url_remap.filename STRING remap.config
CONFIG proxy.config.ssl.server.ticket_key.filename STRING NULL
CONFIG proxy.config.http.response_server_str STRING vCDN
CONFIG proxy.config.proxy_name STRING mtpnjvzcdnc100
CONFIG proxy.config.http.cache.max_stale_age INT 0

# misc
CONFIG proxy.config.allocator.hugepages INT 0
CONFIG proxy.config.system.file_max_pct FLOAT 0.200000
CONFIG proxy.config.http.background_fill_active_timeout INT 0
CONFIG proxy.config.http.number_of_redirections INT 2
CONFIG proxy.config.http.server_session_sharing.pool STRING global
CONFIG proxy.config.net.sock_option_flag_in INT 7

```

- Edit `/usr/local/etc/trafficserver/remap.config`:  

```
# Redirect traffic to backend port 18080
map / http://localhost:18080/ 
```

- Edit `/usr/local/etc/trafficserver/storage.config`:   

```
/dev/nvme0n1p1
/dev/nvme1n1p1
/dev/nvme2n1p1
/dev/nvme3n1p1
```

- Edit `/usr/local/etc/trafficserver/ssl_multicert.config`:  

```
dest_ip=* ssl_cert_name=192.168.1.200.cert.pem  
```

- Create a server certificate:  
  - Follow the [instructions](../cert/README.md) to generate the root certificate and make it trusted on the system(s).   
  - Merge the server cert and key files together into a pem file:  

```bash
hostip=192.168.1.200
sudo mkdir -p /usr/local/etc/sslcert
cat ../cert/ca/intermediate/certs/$hostip.cert.pem ../cert/ca/intermediate/private/$hostip.key.pem | sudo tee /usr/local/etc/sslcert/$hostip.cert.pem
sudo chown -R nobody.root /usr/local/etc/sslcert
sudo chmod 770 /usr/local/etc/sslcert
```

### Prepare Cache Disks

```bash
sudo fdisk /dev/nvme0n1   # create a primary partition 
sudo fdisk /dev/nvme1n1   # create a primary partition 
sudo fdisk /dev/nvme2n1   # create a primary partition 
sudo fdisk /dev/nvme3n1   # create a primary partition 
sudo chmod a+rw /dev/nvme?n1p1
sudo chown -v nobody:trafficserver /dev/nvme*
```

### Start/Stop trafficserver

```bash
sudo /usr/local/bin/trafficserver start
sudo /usr/local/bin/trafficserver stop
```

You may also use the scripts:
[start_ats.sh](start_ats.sh)

Verify ATS status with:
```bash
tail -n 20 /usr/local/var/log/trafficserver/diags.log
```

Result should include:
```
[Apr  9 22:18:03.074] [TS_MAIN] NOTE: traffic server running
[Apr  9 22:18:03.089] [ET_NET 11] NOTE: cache enabled`
```

### Optionally, clear cache before starting trafficserver
```bash
sudo /usr/local/bin/trafficserver stop
sudo /usr/local/bin/traffic_server -Cclear
sudo /usr/local/bin/trafficserver start
```
You may also use the script:
[start_ats_clearcache.sh](start_ats_clearcache.sh)

### Setup Content Origin

See [Origin Setup](../origin/README.md)

### Verify Cache Key (Optional)

In order to be sure ATS uses both uri and query string sections of a url, run a quick test:

Add `xdebug.so` to `/usr/local/etc/trafficserver/plugin.conf`

Restart ATS and verify with:
``` 
/usr/local/bin/trafficserver restart
tail -n 50 /usr/local/var/log/trafficserver/diags.log | grep xdebug
```
Query cache key and make sure query params version and thread are included in the key as in the example:
```
curl 'http://192.168.1.200:8080/_1mobject?version=jf3clx00310289&thread=2' -v  -H 'X-Debug: X-Cache-Key' -o /dev/null 2>&1 | grep X-Cache-Key
> X-Debug: X-Cache-Key
< X-Cache-Key: http://192.168.1.200:8080/_1mobject?version=jf3clx00310289&thread=2
```

### Extract ATS stats including hit ratios, error stats

Cache stats including hit/miss ratios for RAM and disk caches:

```
watch "traffic_logstats -s | head -n 25"
```

Example:

```
Every 2.0s: traffic_logstats -s | head -n 25                                                                 jf3clx001: Thu Apr  9 23:50:47 2020

                       	Totals (all Origins combined)

Request Result                         Count    Percent       Bytes    Percent
------------------------------------------------------------------------------
Cache hit                                 32	  0.06%     32.01MB	 0.06%
Cache hit RAM                         51,121     99.94%     49.94GB     99.94%
Cache hit IMS                              0	  0.00%      0.00KB	 0.00%
Cache hit refresh                          0	  0.00%      0.00KB	 0.00%
Cache hit other                            0	  0.00%      0.00KB	 0.00%
Cache hit total                       51,153    100.00%     49.97GB    100.00%

Cache miss                                 0	  0.00%      0.00KB	 0.00%
Cache miss IMS                             0	  0.00%      0.00KB	 0.00%
Cache miss refresh                         0	  0.00%      0.00KB	 0.00%
Cache miss other                           0	  0.00%      0.00KB	 0.00%
Cache miss total                           0	  0.00%      0.00KB	 0.00%

Client aborted                             0	  0.00%      0.00KB	 0.00%
Client read error                          0	  0.00%      0.00KB	 0.00%
Connect failed                             0	  0.00%      0.00KB	 0.00%
Invalid request                            0	  0.00%      0.00KB	 0.00%
Unknown error(99)                          0	  0.00%      0.00KB	 0.00%
Other errors                               0	  0.00%      0.00KB	 0.00%
Errors total                               0	  0.00%      0.00KB	 0.00%
..............................................................................
```

### Cache Hit Ratios using dstat:

CPU, Disk stats can provide a view into cache hit ratio stats.  dsk/total column maps to hits (read), misses (writes).

```
# dstat -c -d -Dtotal,nvme0n1,nvme1n1,nvme2n1,nvme3n1
----total-usage---- dsk/nvme0n1-dsk/nvme1n1-dsk/nvme2n1-dsk/nvme3n1--dsk/total-
usr sys idl wai stl| read  writ: read  writ: read  writ: read  writ: read  writ
 13   4  65  18   0|2587M    0 :2548M    0 :2456M    0 :2540M    0 :  10G    0
 15   5  55  24   0|2737M    0 :2657M    0 :2574M    0 :2576M    0 :  10G   84k
 15   4  68  13   0|2244M    0 :2216M    0 :2225M    0 :2316M    0 :9016M 3340k
 15   4  69  12   0|2376M    0 :2260M    0 :2218M    0 :2353M    0 :9208M    0
 15   4  68  12   0|2335M    0 :2213M    0 :2274M    0 :2329M    0 :9168M 3452k
 15   4  70  11   0|2211M    0 :2208M    0 :2250M    0 :2280M    0 :8949M    0
```

### traffic_top

Another method to get detailed ATS info:

```
traffic_top
```

![traffic_top_example](traffic_top_example.png)

### Benchmark

See [WRK README](../wrk/README.md).


### Instrumentation

See [instrument.md](instrument.md) for lttng instrumentation.

### Adding QAT to ATS

See [QAT.md](QAT.md) for instructions on adding QAT offloading to ATS (Work In Progress).

