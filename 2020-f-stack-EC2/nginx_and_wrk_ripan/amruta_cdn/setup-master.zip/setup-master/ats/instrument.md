
### LTTNG Instrumentation

A lttng-instrumented ATS version is available. Enable lttng-tracing as follows:   

```bash
git clone https://gitlab.devtools.intel.com/cdn/ats-dev
cd ats-dev/ats-8.0.6
autoreconf -i
./configure --with-lttng-ust
```

### Customize LTTNG Tracing Code

Edit `include/tp.h.in` to add lttng tracing function definition, an example as follows:  

```
TRACEPOINT_EVENT_INSTANCE(
    trafficserver,
    null_argv,
    iocore_aio_insert,
    TP_ARGS()
)
```

Then in any ATS code, add the tracing statement as follows:   

```
#include "tp.h"

...

tracepoint(trafficserver, iocore_aio_insert)
```

Then run `./configure --with-lttng-ust` and `make`.   

### Pre-defined LTTNG Event Classes

The following event classes are defined to include parameters into the LTTNG tracing points: 

```
TRACEPOINT_EVENT_CLASS(
    trafficserver,
    size_argv,
    TP_ARGS( size_t, size ),
    TP_FIELDS( ctf_integer(size_t, size, size) )
)

TRACEPOINT_EVENT_CLASS(
    trafficserver,
    opcode_argv,
    TP_ARGS( int, opcode ),
    TP_FIELDS( ctf_integer(int, opcode, opcode) )
)

TRACEPOINT_EVENT_CLASS(
    trafficserver,
    null_argv,
    TP_ARGS(),
    TP_FIELDS()
)

TRACEPOINT_EVENT_CLASS(
    trafficserver,
    name_argv,
    TP_ARGS( char*, name ),
    TP_FIELDS( ctf_string( name, name ) )
)
```
