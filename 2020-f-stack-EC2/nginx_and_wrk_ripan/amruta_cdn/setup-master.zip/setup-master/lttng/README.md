
### Build

- Build lttng-modules:   

```bash
# only the master works for CentOS 8.1 kernel 4.18
git clone https://git.lttng.org/lttng-modules.git
cd lttng-modules
make
sudo make modules_install
sudo depmod -a
```

- Build userspace-rcu:  

```bash
git clone https://github.com/urcu/userspace-rcu.git
cd userspace-rcu
git checkout tags/v0.11.1
./bootstrap
./configure
make
sudo make install
sudo ldconfig
```

- Build lttng-ust: 

```bash
sudo dnf --enablerepo=PowerTools install -y userspace-rcu-devel

git clone https://git.lttng.org/lttng-ust.git
cd lttng-ust
./bootstrap
./configure --disable-man-pages
make
sudo make install
sudo ldconfig
```

- Build lttng-tools:

```bash
git clone https://git.lttng.org/lttng-tools.git
cd lttng-tools
./bootstrap
export PKG_CONFIG_PATH=/usr/local/lib/pkgconfig
./configure --disable-man-pages
make
sudo make install
sudo ldconfig
```

- Build babeltrace2:  

```bash
sudo dnf install -y glib2-devel

git clone https://github.com/efficios/babeltrace.git
cd babeltrace
./bootstrap
./configure --disable-man-pages --disable-debug-info --disable-doxgen-html 
make
sudo make install
```




