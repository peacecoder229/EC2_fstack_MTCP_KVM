#!/bin/bash -e

sudo systemctl stop irqbalance.service
sudo systemctl disable irqbalance.service
sudo sysctl -w kernel.numa_balancing=0

for dev in $@; do
    mask=$(numactl -a -N netdev:$dev grep allowed /proc/self/status | awk '/Cpus_allowed:/{print$2}')
    echo "dev $dev mask $mask"
    for irq in $(grep -e $dev /proc/interrupts | cut -f1 -d':'); do
        echo "pin irq $irq to $mask"
        echo $mask | sudo tee /proc/irq/$irq/smp_affinity
    done
done
