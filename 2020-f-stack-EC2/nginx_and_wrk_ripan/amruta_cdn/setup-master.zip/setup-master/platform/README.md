
### Platform Setup

- Follow the [slides](https://teams.microsoft.com/l/file/7276EA72-4C6F-4497-BE9C-53787237D236?tenantId=46c98d88-e344-4ed4-8496-4ed7712e255d&fileType=pptx&objectUrl=https%3A%2F%2Fintel.sharepoint.com%2Fsites%2FCDNOptimizationProjects%2FShared%20Documents%2FGeneral%2FVCSE-Dev-Lab-Config-v4.pptx&baseUrl=https%3A%2F%2Fintel.sharepoint.com%2Fsites%2FCDNOptimizationProjects&serviceName=teams&threadId=19:b3f9ea18a4d9483192b5935341761270@thread.tacv2&groupId=cddb2ba5-99d3-4c4d-9f7d-b4ffd242d562) to setup the platforms/hardwares.   
- To enable tri-mode storage, download supported Intel(R) RAID Controllers RMSP3JD160J firmware from [here](https://downloadcenter.intel.com/download/28980/Firmware-Package-for-Intel-Storage-Module-RMSP3JD160J-and-Intel-Storage-Adapter-RSP3QD160J-RSP3GD016J?wapkw=rmsp3jd160j),follow [README](https://downloadmirror.intel.com/28980/eng/SAS3.5_IT_FW_PH10_Readme.txt) to upgrade firmware.
- Enter BIOS setup, select "Advanced -> PCI Configuration -> UEFI Option ROM Control -> RMSP3JD160J (PCISlot=0x11) Configuration Slot :0x211", execute "Refresh Topology" to discover devices, select 'OK', finally slect "Device Properties -> Direct Attached Devices", you'll see 2 x NVME-SSD-NVME INTEL SSDPE2KX02.

### OS

- Install CentOS 8.1 server-version and update to the latest versions.  
- Setup network proxies and append `192.168.1.100` and `192.168.1.200` to your `no_proxy`.  
- Upgrade to elrepo latest CentOS kernel (tracking upstream)

```bash
sudo rpm --import https://www.elrepo.org/RPM-GPG-KEY-elrepo.org
sudo yum install https://www.elrepo.org/elrepo-release-8.el8.elrepo.noarch.rpm
sudo yum --enablerepo=elrepo-kernel install kernel-ml
```

Checking new kernel entry by
ls /boot/loader/entries/

Set default boot kernel by
vi /boot/grub2/grubenv

### Update sysctl settings for optimal network, scheduler performance

Merge contents of [`etc-sysctl.conf`](etc-sysctl.conf) to your `/etc/sysctl.conf`

```bash
# cat /etc/sysctl.conf | grep -v ^#
net.core.wmem_max=568435456
net.core.rmem_max=568435456
net.ipv4.tcp_rmem= 10240 87380 125829120
net.ipv4.tcp_wmem= 10240 87380 125829120
net.ipv4.tcp_window_scaling = 1
net.ipv4.tcp_timestamps = 0
net.ipv4.tcp_sack = 1
net.ipv4.ip_forward=1
net.ipv4.tcp_tw_reuse = 1
net.ipv4.ip_local_port_range = 9000 65535
net.ipv4.tcp_low_latency=1
net.core.netdev_max_backlog=250000
net.core.default_qdisc=fq
fs.file-max=99999999
fs.aio-max-nr=1048576
vm.swappiness=1
vm.vfs_cache_pressure=1000
kernel.sched_latency_ns=1000000
kernel.sched_migration_cost_ns=90000000
kernel.sched_min_granularity_ns=500000
kernel.sched_wakeup_granularity_ns=500000
```

### Intel E801-C CVL Ethernet Adapator Driver Installation

Download the CVL driver from https://cdrdv2.intel.com/v1/dl/getContent/615235.   

TBD: Update the CVL firmware.  

```
unzip 615235-cvl1-4-sampling.zip
cd PROCGB/Linux
tar xvfz ice-0.16.1.tar.gz
cd ice-0.16.1/src
make clean
make
make install
rmmod ice; modprobe ice
```

### IRQ and NUMA Balancing

Run the [`pin_netdev_irq.sh`](pin_netdev_irq.sh) to disable IRQ and NUMA balancing and pin the IRQs to the socket.

```bash
sudo dnf install numactl
./pin_netdev_irq.sh ens785f0 ens785f1
```

### Network Bond

- Create a network script `/etc/sysconfig/network-scripts/ifcfg-bond0`:   

```bash
DEVICE=bond0
NAME=bond0
TYPE=Bond
BONDING_MASTER=yes
IPADDR=192.168.1.200   # 192.168.1.100 for the testgen node
PREFIX=24
ONBOOT=yes
BOOTPROTO=none
BONDING_OPTS="mode=4 miimon=100 updelay=0 downdelay=0"
TYPE=Bond
```

- Configure the two network scripts:  

`/etc/sysconfig/network-scripts/ifcfg-ens786f0`:  

```bash
TYPE=Ethernet
PROXY_METHOD=none
BROWSER_ONLY=no
BOOTPROTO=none
DEFROUTE=yes
PEERROUTES=yes
IPV4_FAILURE_FATAL=no
IPV6INIT=yes
IPV6_AUTOCONF=yes
IPV6_DEFROUTE=yes
IPV6_PRERNDS=yes
IPV6_PEERROUTES=yes
IPV6_FAILURE_FATAL=no
NAME=ens785f0
UUID=1bc50439-f2a6-4e97-aa93-885f1a0f3d33
DEVICE=ens785f0
ONBOOT=yes
MASTER=bond0
SLAVE=yes
```

`/etc/sysconfig/network-scripts/ifcfg-ens786f1`:  

```bash
TYPE=Ethernet
PROXY_METHOD=none
BROWSER_ONLY=no
BOOTPROTO=none
DEFROUTE=yes
PEERROUTES=yes
IPV4_FAILURE_FATAL=no
IPV6INIT=yes
IPV6_AUTOCONF=yes
IPV6_DEFROUTE=yes
IPV6_PRERNDS=yes
IPV6_PEERROUTES=yes
IPV6_FAILURE_FATAL=no
NAME=ens785f1
UUID=0d8be264-5fb2-4805-8d66-4adc8040d103
DEVICE=ens785f1
ONBOOT=yes
MASTER=bond0
SLAVE=yes
```

- Activate the networks: 

```bash
sudo ifup ens785f0
sudo ifup ens785f1
sudo ifup bond0
```

- Disable firewall:

```bash
sudo systemctl stop firewalld
sudo systemctl disable firewalld
```

### Test Network Speed:

- Build `iperf2` (do not use `iperf3` to test 10Gbps and beyond):   

```bash
git clone https://git.code.sf.net/p/iperf2/code iperf2-code
cd iperf2-code
git checkout 41bfc67  # 2.0.13
./configure --prefix=/usr/local
make
sudo make install
```

- Run `iperf` on the client & server

```bash
# 192.168.1.200
iperf -s
```

```bash
# 192.168.1.100
iperf -c 192.168.1.200 -P 12
```
### Set fstab to have all NVME diskes as cache
cat /etc/fstab

/dev/nvme0n1 /mnt/cache0 ext4 rw,noatime,seclabel,discard 0 0
/dev/nvme1n1 /mnt/cache1 ext4 rw,noatime,seclabel,discard 0 0
/dev/nvme2n1 /mnt/cache2 ext4 rw,noatime,seclabel,discard 0 0
/dev/nvme3n1 /mnt/cache3 ext4 rw,noatime,seclabel,discard 0 0
/dev/nvme4n1 /mnt/cache4 ext4 rw,noatime,seclabel,discard 0 0
/dev/nvme5n1 /mnt/cache5 ext4 rw,noatime,seclabel,discard 0 0
/dev/sdc /mnt/cache6 ext4 rw,noatime,seclabel,discard 0 0
/dev/sdd /mnt/cache6 ext4 rw,noatime,seclabel,discard 0 0

### use sar to monitor runtime network interface performance
sar -n DEV 1 -h

### SSD precondition script
- Note: you need change the filename inside to reflect the real SSD device
fio ssd-precondition.fio
